  <!--<< Breadcrumb Section Start >>-->
  <div class="breadcrumb-wrapper bg-cover" style="background-image: url('assets/img/breadcrumb.jpg');">
    <div class="border-shape">
        <img src="assets/img/element.png" alt="shape-img">
    </div>
    <div class="line-shape">
        <img src="assets/img/line-element.png" alt="shape-img">
    </div>
    <div class="container">
        <div class="page-heading">
            <h1 class="wow fadeInUp" data-wow-delay=".3s">Permintaan Penawaran</h1>
            <ul class="breadcrumb-items wow fadeInUp" data-wow-delay=".5s">
                <li>
                    <a href="index.html">
                        Home
                    </a>
                </li>
                <li>
                    <i class="fas fa-chevron-right"></i>
                </li>
                <li>
                    Permintaan Penawaran
                </li>
            </ul>
        </div>
    </div>
</div><?php /**PATH D:\AGIM-HIDAYAT\PROJECT\laravel-app\telegram-contact-form\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>