<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
</head>
<body>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

    <form action="<?php echo e(route('send.message')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="name">Nama:</label><br>
        <input type="text" id="name" name="name"><br>
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email"><br>
        <label for="message">Pesan:</label><br>
        <textarea id="message" name="message"></textarea><br><br>
        <button type="submit">Kirim Pesan</button>
    </form>
</body>
</html>
<?php /**PATH D:\AGIM-HIDAYAT\PROJECT\laravel-app\telegram-contact-form\resources\views/contact.blade.php ENDPATH**/ ?>